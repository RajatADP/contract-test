package com.service.creditcheck;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CreditCheckApplication {

	public static void main(String[] args) {
		SpringApplication.run(CreditCheckApplication.class, args);
	}

}
